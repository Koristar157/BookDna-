import { createClient } from "@supabase/supabase-js";

// These are real client factories — but they require YOUR Supabase project's
// URL/keys in .env.local. Until you set those, any code path that calls these
// will simply have no database to talk to; the UI is written to show empty
// states ("Sign in to build your shelves") rather than fabricated user data.

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export function getSupabaseBrowserClient() {
  if (!url || !anonKey) {
    throw new Error(
      "Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in .env.local — see supabase/schema.sql for the schema to run first."
    );
  }
  return createClient(url, anonKey);
}

export function getSupabaseServiceClient() {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) {
    throw new Error(
      "Supabase service role is not configured. Set SUPABASE_SERVICE_ROLE_KEY in .env.local (server-only, never expose to the client)."
    );
  }
  return createClient(url, serviceKey);
}

export function isSupabaseConfigured(): boolean {
  return Boolean(url && anonKey);
}
