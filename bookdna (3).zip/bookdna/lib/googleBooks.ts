const BASE = "https://www.googleapis.com/books/v1";

export interface GoogleBookInfo {
  description: string | null;
  thumbnail: string | null;
  categories: string[];
  publisher: string | null;
  pageCount: number | null;
  language: string | null;
}

async function safeFetchJson<T>(url: string): Promise<T | null> {
  try {
    const res = await fetch(url, { next: { revalidate: 3600 } });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

/**
 * Google Books fills gaps Open Library leaves: rich descriptions, cover
 * thumbnails, categories, publisher, page count. Used only as a fallback —
 * if this returns nothing, the book page shows "No information available"
 * for those fields rather than fabricating them.
 */
export async function getGoogleBookByIsbn(isbn: string): Promise<GoogleBookInfo | null> {
  const key = process.env.GOOGLE_BOOKS_API_KEY;
  const keyParam = key ? `&key=${key}` : "";
  const data = await safeFetchJson<{ items?: any[] }>(
    `${BASE}/volumes?q=isbn:${encodeURIComponent(isbn)}${keyParam}`
  );
  const item = data?.items?.[0]?.volumeInfo;
  if (!item) return null;

  return {
    description: item.description ?? null,
    thumbnail: item.imageLinks?.thumbnail?.replace("http://", "https://") ?? null,
    categories: item.categories ?? [],
    publisher: item.publisher ?? null,
    pageCount: item.pageCount ?? null,
    language: item.language ?? null,
  };
}

export async function searchGoogleBooksByTitleAuthor(
  title: string,
  author?: string
): Promise<GoogleBookInfo | null> {
  const key = process.env.GOOGLE_BOOKS_API_KEY;
  const keyParam = key ? `&key=${key}` : "";
  const q = author ? `intitle:${title} inauthor:${author}` : `intitle:${title}`;
  const data = await safeFetchJson<{ items?: any[] }>(
    `${BASE}/volumes?q=${encodeURIComponent(q)}${keyParam}`
  );
  const item = data?.items?.[0]?.volumeInfo;
  if (!item) return null;

  return {
    description: item.description ?? null,
    thumbnail: item.imageLinks?.thumbnail?.replace("http://", "https://") ?? null,
    categories: item.categories ?? [],
    publisher: item.publisher ?? null,
    pageCount: item.pageCount ?? null,
    language: item.language ?? null,
  };
}
