// All fields are optional on purpose: real external data is frequently incomplete.
// UI components must handle missing fields by rendering "No information available"
// rather than inventing a value. Never widen these types to include placeholder data.

export interface BookSummary {
  workId: string; // Open Library work key, e.g. "OL45804W"
  title: string;
  authors: string[];
  coverUrl: string | null;
  firstPublishYear: number | null;
  isbn: string | null;
  subjects: string[];
}

export interface BookDetail extends BookSummary {
  description: string | null;
  publisher: string | null;
  pageCount: number | null;
  language: string | null;
  series: string | null;
  editionsCount: number | null;
  googleThumbnail: string | null;
  categories: string[]; // from Google Books, supplements Open Library subjects
}

// BookDNA trait scores are a derived heuristic analysis computed from real
// subjects/description text — never a fabricated or "official" rating.
// See lib/bookdna-traits.ts.
export interface BookDNATraits {
  action: number;
  romance: number;
  humor: number;
  mystery: number;
  fantasy: number;
  sciFi: number;
  politics: number;
  violence: number;
  characterDevelopment: number;
  worldbuilding: number;
  emotionalImpact: number;
  pacing: number;
  plotTwists: number;
}

export interface SearchFilters {
  query?: string;
  genre?: string;
  mood?: string;
  trope?: string;
  theme?: string;
  minYear?: number;
  maxYear?: number;
  maxPageCount?: number;
  minPageCount?: number;
  standaloneOnly?: boolean;
}

export interface SearchResult {
  books: BookSummary[];
  totalFound: number;
  source: "open-library" | "google-books" | "none";
}
