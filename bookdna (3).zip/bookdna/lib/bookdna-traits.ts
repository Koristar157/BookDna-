import type { BookDNATraits } from "./types";

/**
 * BookDNA trait scores are NOT sourced from any external rating provider —
 * no such API exists for this. They are a transparent, deterministic heuristic
 * computed from the book's real subjects + real description text (keyword
 * co-occurrence), and MUST always be labeled in the UI as
 * "BookDNA Analysis — derived, not an official publisher rating."
 *
 * This is intentionally simple and inspectable (not an opaque ML black box)
 * so scores can be explained. Swap in a real embedding/classifier model later
 * without changing the BookDNATraits shape.
 */

const KEYWORD_WEIGHTS: Record<keyof BookDNATraits, string[]> = {
  action: ["action", "adventure", "battle", "war", "combat", "heist", "chase", "fight"],
  romance: ["romance", "love story", "romantic", "lovers", "courtship"],
  humor: ["humor", "humorous", "comedy", "satire", "wit", "funny"],
  mystery: ["mystery", "detective", "crime", "whodunit", "investigation", "suspense"],
  fantasy: ["fantasy", "magic", "dragons", "wizards", "mythical", "sorcery", "epic fantasy"],
  sciFi: ["science fiction", "sci-fi", "space", "dystopia", "cyberpunk", "aliens", "futuristic"],
  politics: ["politics", "political", "intrigue", "court", "monarchy", "war of succession"],
  violence: ["violence", "war", "battle", "death", "brutal", "grimdark"],
  characterDevelopment: ["coming of age", "character study", "growth", "self-discovery", "bildungsroman"],
  worldbuilding: ["worldbuilding", "epic", "saga", "series", "mythology", "invented world"],
  emotionalImpact: ["tragedy", "grief", "heartbreaking", "emotional", "loss", "healing"],
  pacing: ["fast-paced", "page-turner", "thriller", "gripping"],
  plotTwists: ["twist", "unreliable narrator", "reveal", "shocking ending"],
};

function scoreFromText(haystack: string, keywords: string[]): number {
  const hits = keywords.reduce((count, kw) => (haystack.includes(kw) ? count + 1 : count), 0);
  // Normalize to 0-100. A single strong hit already signals presence of the trait;
  // scale so it doesn't require unrealistic keyword density to reach visible bars.
  return Math.min(100, Math.round((hits / Math.max(2, keywords.length * 0.4)) * 100));
}

export function computeBookDNATraits(subjects: string[], description: string | null): BookDNATraits {
  const haystack = `${subjects.join(" ")} ${description ?? ""}`.toLowerCase();

  const entries = (Object.keys(KEYWORD_WEIGHTS) as (keyof BookDNATraits)[]).map((trait) => [
    trait,
    scoreFromText(haystack, KEYWORD_WEIGHTS[trait]),
  ]);

  return Object.fromEntries(entries) as unknown as BookDNATraits;
}

export const TRAIT_LABELS: Record<keyof BookDNATraits, string> = {
  action: "Action",
  romance: "Romance",
  humor: "Humor",
  mystery: "Mystery",
  fantasy: "Fantasy",
  sciFi: "Sci-Fi",
  politics: "Politics",
  violence: "Violence",
  characterDevelopment: "Character Development",
  worldbuilding: "Worldbuilding",
  emotionalImpact: "Emotional Impact",
  pacing: "Pacing",
  plotTwists: "Plot Twists",
};
