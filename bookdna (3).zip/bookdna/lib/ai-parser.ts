import type { SearchFilters } from "./types";

/**
 * Converts a natural-language query ("a cozy fantasy with dragons and almost
 * no romance") into real SearchFilters that map to genuine Open Library
 * subjects/queries. This NEVER invents book results — it only extracts filter
 * intent; the actual books still come from live searchBooks() calls.
 *
 * Default implementation: deterministic keyword/negation parsing (no API key
 * required, fully offline, always available).
 *
 * Optional upgrade: if ANTHROPIC_API_KEY is set, parseWithClaude() asks Claude
 * to extract the same structured filters with better recall on phrasing Claude
 * understands but simple keyword matching misses. Either path only ever
 * produces *filters* — never fabricated book data.
 */

const GENRE_KEYWORDS: Record<string, string[]> = {
  fantasy: ["fantasy", "dragons", "magic", "wizards"],
  romance: ["romance", "love story"],
  mystery: ["mystery", "whodunit", "detective"],
  "science fiction": ["sci-fi", "science fiction", "space opera"],
  horror: ["horror", "scary"],
  thriller: ["thriller", "suspense"],
  "historical fiction": ["historical fiction", "historical"],
  "literary fiction": ["literary fiction"],
};

const TROPE_KEYWORDS: Record<string, string[]> = {
  "enemies to lovers": ["enemies to lovers", "enemies-to-lovers"],
  "found family": ["found family"],
  "slow burn": ["slow burn"],
  "morally gray": ["morally gray", "morally grey"],
  heist: ["heist"],
  "dark academia": ["dark academia"],
  "multiple pov": ["multiple pov", "multi-pov"],
};

const MOOD_KEYWORDS: Record<string, string[]> = {
  cozy: ["cozy", "comforting", "wholesome"],
  dark: ["dark", "grim", "grimdark"],
  "fast-paced": ["fast paced", "fast-paced", "page turner"],
  emotional: ["emotional", "heart wrenching", "tearjerker"],
};

const NEGATION_PATTERN = /\b(no|almost no|without|not much|little)\s+([a-z\s]+?)(?:[,.]|$| and )/gi;

function findFirstMatch(text: string, table: Record<string, string[]>): string | undefined {
  for (const [canonical, variants] of Object.entries(table)) {
    if (variants.some((v) => text.includes(v))) return canonical;
  }
  return undefined;
}

export interface ParsedIntent {
  filters: SearchFilters;
  excluded: string[]; // things the user explicitly wants little/none of, e.g. "romance"
  rawQuery: string;
}

export function parseQueryDeterministic(rawQuery: string): ParsedIntent {
  const text = rawQuery.toLowerCase();

  const excluded: string[] = [];
  let match: RegExpExecArray | null;
  const negRe = new RegExp(NEGATION_PATTERN);
  while ((match = negRe.exec(text)) !== null) {
    const captured = match[2];
    if (captured) excluded.push(captured.trim());
  }

  const genre = findFirstMatch(text, GENRE_KEYWORDS);
  const trope = findFirstMatch(text, TROPE_KEYWORDS);
  const mood = findFirstMatch(text, MOOD_KEYWORDS);

  // Strip stopwords/negated terms so the residual becomes a general keyword query
  // Open Library can still use for full-text relevance.
  const cleanedQuery = rawQuery
    .replace(NEGATION_PATTERN, " ")
    .replace(/\b(i want|a|an|the|with|and|book|books)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();

  return {
    filters: {
      query: cleanedQuery || undefined,
      genre,
      trope,
      mood,
    },
    excluded,
    rawQuery,
  };
}

/**
 * Optional: real LLM-backed parsing via the Anthropic API, used only if
 * ANTHROPIC_API_KEY is configured server-side. Falls back to the
 * deterministic parser on any failure — never blocks search.
 */
export async function parseQuery(rawQuery: string): Promise<ParsedIntent> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return parseQueryDeterministic(rawQuery);

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 300,
        system:
          "Extract book-search filters as strict JSON only: " +
          '{"genre": string|null, "trope": string|null, "mood": string|null, ' +
          '"excluded": string[], "query": string}. No prose, JSON only.',
        messages: [{ role: "user", content: rawQuery }],
      }),
    });
    if (!res.ok) return parseQueryDeterministic(rawQuery);
    const data = await res.json();
    const text = data?.content?.[0]?.text ?? "";
    const parsed = JSON.parse(text.replace(/```json|```/g, "").trim());
    return {
      filters: {
        query: parsed.query || undefined,
        genre: parsed.genre || undefined,
        trope: parsed.trope || undefined,
        mood: parsed.mood || undefined,
      },
      excluded: parsed.excluded ?? [],
      rawQuery,
    };
  } catch {
    return parseQueryDeterministic(rawQuery);
  }
}
