-- BookDNA schema. Run this in the Supabase SQL editor for a fresh project.
-- Books themselves are never stored redundantly as fabricated rows here —
-- this schema stores only USER data (shelves, reviews, stats) referencing
-- books by their real Open Library work id ("open_library_id").

create extension if not exists "uuid-ossp";

-- Supabase auth.users is the source of truth for accounts; this table holds
-- public profile info only.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.shelves (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null, -- "Favorites" | "Currently Reading" | "Finished" | "Want to Read" | custom
  is_system boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, name)
);

create table if not exists public.shelf_items (
  id uuid primary key default uuid_generate_v4(),
  shelf_id uuid not null references public.shelves(id) on delete cascade,
  open_library_id text not null, -- real work id, e.g. "OL45804W"
  added_at timestamptz not null default now(),
  unique (shelf_id, open_library_id)
);

create table if not exists public.reviews (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  open_library_id text not null,
  rating smallint check (rating between 1 and 5),
  body text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.reading_progress (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  open_library_id text not null,
  status text not null check (status in ('want_to_read','currently_reading','finished')),
  pages_read int default 0,
  started_at timestamptz,
  finished_at timestamptz,
  unique (user_id, open_library_id)
);

create table if not exists public.reading_goals (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  year int not null,
  target_books int not null,
  unique (user_id, year)
);

-- Admin moderation / search analytics (populated by app usage, never seeded with fake rows)
create table if not exists public.search_log (
  id uuid primary key default uuid_generate_v4(),
  query text not null,
  result_count int not null,
  created_at timestamptz not null default now()
);

create table if not exists public.flagged_content (
  id uuid primary key default uuid_generate_v4(),
  review_id uuid references public.reviews(id) on delete cascade,
  reason text not null,
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);

-- Row Level Security: users manage their own data only.
alter table public.profiles enable row level security;
alter table public.shelves enable row level security;
alter table public.shelf_items enable row level security;
alter table public.reviews enable row level security;
alter table public.reading_progress enable row level security;
alter table public.reading_goals enable row level security;

create policy "profiles are viewable by everyone" on public.profiles for select using (true);
create policy "users manage their own profile" on public.profiles for update using (auth.uid() = id);

create policy "users manage their own shelves" on public.shelves for all using (auth.uid() = user_id);
create policy "shelf items follow shelf owner" on public.shelf_items for all using (
  exists (select 1 from public.shelves s where s.id = shelf_id and s.user_id = auth.uid())
);

create policy "reviews are viewable by everyone" on public.reviews for select using (true);
create policy "users manage their own reviews" on public.reviews for insert with check (auth.uid() = user_id);
create policy "users update their own reviews" on public.reviews for update using (auth.uid() = user_id);
create policy "users delete their own reviews" on public.reviews for delete using (auth.uid() = user_id);

create policy "users manage their own progress" on public.reading_progress for all using (auth.uid() = user_id);
create policy "users manage their own goals" on public.reading_goals for all using (auth.uid() = user_id);
