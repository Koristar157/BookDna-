import { NextRequest, NextResponse } from "next/server";
import { searchBooks } from "@/lib/openLibrary";
import type { SearchFilters } from "@/lib/types";

export async function GET(req: NextRequest) {
  const params = req.nextUrl.searchParams;
  const filters: SearchFilters = {
    query: params.get("q") ?? undefined,
    genre: params.get("genre") ?? undefined,
    mood: params.get("mood") ?? undefined,
    trope: params.get("trope") ?? undefined,
    theme: params.get("theme") ?? undefined,
    minYear: params.get("minYear") ? Number(params.get("minYear")) : undefined,
    maxYear: params.get("maxYear") ? Number(params.get("maxYear")) : undefined,
  };
  const page = Number(params.get("page") ?? "1");

  const result = await searchBooks(filters, 24, page);
  return NextResponse.json(result);
}
