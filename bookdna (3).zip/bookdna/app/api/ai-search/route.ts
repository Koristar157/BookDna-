import { NextRequest, NextResponse } from "next/server";
import { parseQuery } from "@/lib/ai-parser";
import { searchBooks } from "@/lib/openLibrary";

export async function POST(req: NextRequest) {
  const { query } = await req.json();
  if (!query || typeof query !== "string") {
    return NextResponse.json({ error: "Missing query" }, { status: 400 });
  }

  const intent = await parseQuery(query);
  const result = await searchBooks(intent.filters, 24, 1);

  return NextResponse.json({
    ...result,
    interpretedAs: intent.filters,
    excluded: intent.excluded,
  });
}
