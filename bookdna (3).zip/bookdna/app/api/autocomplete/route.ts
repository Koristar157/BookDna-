import { NextRequest, NextResponse } from "next/server";
import { autocomplete } from "@/lib/openLibrary";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q") ?? "";
  const books = await autocomplete(q);
  return NextResponse.json({ books });
}
