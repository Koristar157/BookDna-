// Real blog content belongs in a CMS or the `posts` table you add to Supabase.
// This intentionally ships empty rather than with placeholder/lorem-ipsum posts.
export const metadata = { title: "Blog" };

export default function BlogPage() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-20 text-center">
      <h1 className="font-display text-3xl text-ink-900 dark:text-parchment mb-4">Blog</h1>
      <p className="font-body text-ink-600 dark:text-ink-300">
        No posts yet. Connect a `posts` table (or a headless CMS) and list real entries here —
        reading guides, author spotlights, and genre roundups all read naturally from real BookDNA
        data once written.
      </p>
    </div>
  );
}
