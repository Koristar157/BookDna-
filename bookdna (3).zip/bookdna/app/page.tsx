import Hero from "@/components/Hero";
import Section from "@/components/Section";
import BookGrid, { EmptyState } from "@/components/BookGrid";
import Link from "next/link";
import { getTrending, getBooksBySubject } from "@/lib/openLibrary";

export const revalidate = 1800; // homepage rails refresh every 30 min

const GENRES = ["fantasy", "romance", "mystery", "science_fiction", "horror", "historical_fiction"];
const MOODS = ["cozy", "dark_academia", "adventure", "tearjerker"];

export default async function HomePage() {
  const [trending, recentlyPopular, awardWinners, hiddenGems] = await Promise.all([
    getTrending("weekly", 12),
    getTrending("daily", 12),
    getBooksBySubject("award_winners", 12),
    getBooksBySubject("underground", 12), // best-effort proxy for lesser-known titles; see README
  ]);

  return (
    <>
      <Hero />

      <Section title="Trending this week" eyebrow="Live from Open Library" viewAllHref="/browse/trending">
        {trending.length ? <BookGrid books={trending} /> : <EmptyState />}
      </Section>

      <Section title="Recently popular" eyebrow="Updated daily">
        {recentlyPopular.length ? <BookGrid books={recentlyPopular} /> : <EmptyState />}
      </Section>

      <Section title="Award winners" eyebrow="Real award-tagged subjects">
        {awardWinners.length ? <BookGrid books={awardWinners} /> : <EmptyState />}
      </Section>

      <Section title="Hidden gems" eyebrow="Lower-visibility, still real">
        {hiddenGems.length ? <BookGrid books={hiddenGems} /> : <EmptyState />}
      </Section>

      <section className="mx-auto max-w-6xl px-6 py-16">
        <h2 className="font-display text-2xl font-medium text-ink-900 dark:text-parchment mb-6">
          Browse by genre
        </h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-6">
          {GENRES.map((g) => (
            <Link
              key={g}
              href={`/browse/genre/${g}`}
              className="rounded border border-ink-100 dark:border-ink-700 px-4 py-6 text-center font-display capitalize text-ink-900 dark:text-parchment hover:border-berry hover:text-berry transition-colors focus-ring"
            >
              {g.replace("_", " ")}
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-20">
        <h2 className="font-display text-2xl font-medium text-ink-900 dark:text-parchment mb-6">
          Browse by mood
        </h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {MOODS.map((m) => (
            <Link
              key={m}
              href={`/browse/mood/${m}`}
              className="rounded border border-ink-100 dark:border-ink-700 px-4 py-6 text-center font-display capitalize text-ink-900 dark:text-parchment hover:border-berry hover:text-berry transition-colors focus-ring"
            >
              {m.replace("_", " ")}
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
