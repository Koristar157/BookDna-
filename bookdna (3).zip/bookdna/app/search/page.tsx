import { Suspense } from "react";
import { searchBooks } from "@/lib/openLibrary";
import BookGrid, { EmptyState } from "@/components/BookGrid";
import SearchBar from "@/components/SearchBar";
import FilterPanel from "@/components/FilterPanel";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Search" };

export default async function SearchPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | undefined };
}) {
  const filters = {
    query: searchParams.q,
    genre: searchParams.genre,
    mood: searchParams.mood,
    trope: searchParams.trope,
    theme: searchParams.theme,
    minYear: searchParams.minYear ? Number(searchParams.minYear) : undefined,
    maxYear: searchParams.maxYear ? Number(searchParams.maxYear) : undefined,
  };

  const hasAnyFilter = Object.values(filters).some(Boolean);
  const result = hasAnyFilter
    ? await searchBooks(filters, 30, Number(searchParams.page ?? "1"))
    : { books: [], totalFound: 0, source: "none" as const };

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <SearchBar />
      <div className="mt-8 grid gap-8 md:grid-cols-[220px_1fr]">
        <Suspense fallback={null}>
          <FilterPanel currentFilters={filters} />
        </Suspense>
        <div>
          <p className="mb-4 font-body text-sm text-ink-500 dark:text-ink-300">
            {hasAnyFilter
              ? `${result.totalFound.toLocaleString()} real books found`
              : "Enter a search or pick a filter to begin."}
          </p>
          {hasAnyFilter && result.books.length === 0 ? (
            <EmptyState message="No information available. Try a broader search or different filters." />
          ) : (
            <BookGrid books={result.books} />
          )}
        </div>
      </div>
    </div>
  );
}
