import Image from "next/image";
import type { Metadata } from "next";
import { getWorkDetails, getWorkEditions, getAuthorName } from "@/lib/openLibrary";
import { getGoogleBookByIsbn, searchGoogleBooksByTitleAuthor } from "@/lib/googleBooks";
import { computeBookDNATraits } from "@/lib/bookdna-traits";
import TraitBars from "@/components/TraitBars";
import BuyLinks from "@/components/BuyLinks";
import { EmptyState } from "@/components/BookGrid";
import { notFound } from "next/navigation";

async function loadBook(workId: string) {
  const work = await getWorkDetails(workId);
  if (!work) return null;

  const editions = await getWorkEditions(workId, 5);
  const firstEdition = editions[0];
  const isbn: string | null = firstEdition?.isbn_13?.[0] ?? firstEdition?.isbn_10?.[0] ?? null;

  const authorKeys: string[] = (work as any).authors?.map((a: any) => a.author?.key).filter(Boolean) ?? [];
  const authorNames = (await Promise.all(authorKeys.map((k) => getAuthorName(k.replace("/authors/", ""))))).filter(
    Boolean
  ) as string[];

  const google = isbn
    ? await getGoogleBookByIsbn(isbn)
    : await searchGoogleBooksByTitleAuthor(work.title, authorNames[0]);

  const description =
    typeof work.description === "string" ? work.description : work.description?.value ?? google?.description ?? null;

  const coverId = work.covers?.[0];
  const coverUrl = coverId
    ? `https://covers.openlibrary.org/b/id/${coverId}-L.jpg`
    : google?.thumbnail ?? null;

  return {
    workId,
    title: work.title,
    authors: authorNames,
    description,
    subjects: work.subjects ?? [],
    isbn,
    publisher: google?.publisher ?? null,
    pageCount: google?.pageCount ?? null,
    language: google?.language ?? null,
    editionsCount: editions.length,
    coverUrl,
    categories: google?.categories ?? [],
  };
}

export async function generateMetadata({ params }: { params: { workId: string } }): Promise<Metadata> {
  const book = await loadBook(params.workId);
  if (!book) return { title: "Book not found" };
  return {
    title: book.title,
    description: book.description
      ? book.description.slice(0, 155)
      : `${book.title} by ${book.authors.join(", ") || "an unknown author"} — real book data on BookDNA.`,
    openGraph: {
      title: book.title,
      description: book.description?.slice(0, 155),
      images: book.coverUrl ? [book.coverUrl] : [],
    },
  };
}

export default async function BookPage({ params }: { params: { workId: string } }) {
  const book = await loadBook(params.workId);
  if (!book) notFound();

  const traits = computeBookDNATraits(book.subjects, book.description);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Book",
    name: book.title,
    author: book.authors.map((name) => ({ "@type": "Person", name })),
    isbn: book.isbn ?? undefined,
    numberOfPages: book.pageCount ?? undefined,
    inLanguage: book.language ?? undefined,
    publisher: book.publisher ?? undefined,
    image: book.coverUrl ?? undefined,
  };

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="grid gap-10 md:grid-cols-[280px_1fr]">
        <div>
          <div className="relative aspect-[2/3] w-full overflow-hidden rounded bg-ink-100 dark:bg-ink-700 shadow-lg">
            {book.coverUrl ? (
              <Image src={book.coverUrl} alt={`Cover of ${book.title}`} fill className="object-cover" priority />
            ) : (
              <div className="flex h-full items-center justify-center font-body text-sm text-ink-400">
                No cover available
              </div>
            )}
          </div>
          <div className="mt-6">
            <BuyLinks title={book.title} isbn={book.isbn} />
          </div>
        </div>

        <div>
          <h1 className="font-display text-4xl font-semibold text-ink-900 dark:text-parchment">{book.title}</h1>
          <p className="mt-2 font-body text-lg text-ink-600 dark:text-ink-300">
            {book.authors.length ? book.authors.join(", ") : "Unknown author"}
          </p>

          <dl className="mt-6 grid grid-cols-2 gap-4 border-y border-ink-100 dark:border-ink-700 py-4 sm:grid-cols-4">
            <Field label="Publisher" value={book.publisher} />
            <Field label="Pages" value={book.pageCount ? String(book.pageCount) : null} />
            <Field label="Language" value={book.language} />
            <Field label="ISBN" value={book.isbn} />
          </dl>

          <div className="mt-6">
            <h2 className="font-display text-xl text-ink-900 dark:text-parchment mb-2">Description</h2>
            {book.description ? (
              <p className="font-body leading-relaxed text-ink-700 dark:text-ink-200 whitespace-pre-line">
                {book.description}
              </p>
            ) : (
              <EmptyState message="No information available." />
            )}
          </div>

          {book.subjects.length > 0 && (
            <div className="mt-6">
              <h2 className="font-display text-xl text-ink-900 dark:text-parchment mb-2">Subjects</h2>
              <div className="flex flex-wrap gap-2">
                {book.subjects.slice(0, 16).map((s) => (
                  <span
                    key={s}
                    className="rounded-full bg-ink-50 dark:bg-ink-800 px-3 py-1 font-body text-xs text-ink-600 dark:text-ink-300"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="mt-10">
            <TraitBars traits={traits} />
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string | null }) {
  return (
    <div>
      <dt className="font-mono text-[10px] uppercase tracking-wider text-ink-400">{label}</dt>
      <dd className="font-body text-sm text-ink-900 dark:text-parchment">{value ?? "No information available."}</dd>
    </div>
  );
}
