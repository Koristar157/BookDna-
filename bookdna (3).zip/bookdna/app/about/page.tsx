export const metadata = { title: "About" };

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-20">
      <h1 className="font-display text-3xl text-ink-900 dark:text-parchment mb-4">About BookDNA</h1>
      <p className="font-body leading-relaxed text-ink-700 dark:text-ink-200">
        BookDNA is a book discovery platform, not a review site. Every book shown here is real,
        sourced live from Open Library and Google Books. Nothing is fabricated: no invented
        titles, authors, covers, or ratings. Where real data isn&rsquo;t available, we say so.
      </p>
    </div>
  );
}
