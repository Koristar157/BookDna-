import Link from "next/link";

export const metadata = { title: "Moods" };

const MOODS = ["cozy", "dark_academia", "adventure", "tearjerker", "dark", "fast-paced", "emotional", "underground"];

export default function MoodIndexPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <h1 className="mb-6 font-display text-3xl text-ink-900 dark:text-parchment">Browse by mood</h1>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {MOODS.map((m) => (
          <Link
            key={m}
            href={`/browse/mood/${m}`}
            className="rounded border border-ink-100 dark:border-ink-700 px-4 py-6 text-center font-display capitalize text-ink-900 dark:text-parchment hover:border-berry hover:text-berry transition-colors focus-ring"
          >
            {m.replace(/_/g, " ")}
          </Link>
        ))}
      </div>
    </div>
  );
}
