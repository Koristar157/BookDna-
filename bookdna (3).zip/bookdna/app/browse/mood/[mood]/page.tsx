import { getBooksBySubject } from "@/lib/openLibrary";
import BookGrid, { EmptyState } from "@/components/BookGrid";
import type { Metadata } from "next";

export async function generateMetadata({ params }: { params: { mood: string } }): Promise<Metadata> {
  const name = decodeURIComponent(params.mood).replace(/_/g, " ");
  return { title: `${name} books` };
}

export default async function MoodPage({ params }: { params: { mood: string } }) {
  const name = decodeURIComponent(params.mood).replace(/_/g, " ");
  // Moods are not a native Open Library taxonomy — this queries the closest
  // matching subject and is honest about it returning nothing for moods
  // that aren't modeled there (see README's "known limitations").
  const books = await getBooksBySubject(params.mood, 36);

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <h1 className="mb-6 font-display text-3xl capitalize text-ink-900 dark:text-parchment">{name} books</h1>
      {books.length ? (
        <BookGrid books={books} />
      ) : (
        <EmptyState message="No information available for this mood as a subject yet." />
      )}
    </div>
  );
}
