import { getTrending } from "@/lib/openLibrary";
import BookGrid, { EmptyState } from "@/components/BookGrid";

export const metadata = { title: "Trending" };
export const revalidate = 1800;

export default async function TrendingPage() {
  const books = await getTrending("weekly", 48);
  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <h1 className="mb-6 font-display text-3xl text-ink-900 dark:text-parchment">Trending this week</h1>
      {books.length ? <BookGrid books={books} /> : <EmptyState />}
    </div>
  );
}
