import { getBooksBySubject } from "@/lib/openLibrary";
import BookGrid, { EmptyState } from "@/components/BookGrid";
import type { Metadata } from "next";

export async function generateMetadata({ params }: { params: { genre: string } }): Promise<Metadata> {
  const name = decodeURIComponent(params.genre).replace(/_/g, " ");
  return { title: `${name} books` };
}

export default async function GenrePage({ params }: { params: { genre: string } }) {
  const name = decodeURIComponent(params.genre).replace(/_/g, " ");
  const books = await getBooksBySubject(params.genre, 36);

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <h1 className="mb-6 font-display text-3xl capitalize text-ink-900 dark:text-parchment">{name}</h1>
      {books.length ? <BookGrid books={books} /> : <EmptyState />}
    </div>
  );
}
