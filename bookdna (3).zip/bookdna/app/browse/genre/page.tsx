import Link from "next/link";

export const metadata = { title: "Genres" };

const GENRES = [
  "fantasy",
  "romance",
  "mystery",
  "science_fiction",
  "horror",
  "thriller",
  "historical_fiction",
  "literary_fiction",
  "young_adult",
  "nonfiction",
  "biography",
  "poetry",
];

export default function GenreIndexPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <h1 className="mb-6 font-display text-3xl text-ink-900 dark:text-parchment">Browse by genre</h1>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {GENRES.map((g) => (
          <Link
            key={g}
            href={`/browse/genre/${g}`}
            className="rounded border border-ink-100 dark:border-ink-700 px-4 py-6 text-center font-display capitalize text-ink-900 dark:text-parchment hover:border-berry hover:text-berry transition-colors focus-ring"
          >
            {g.replace(/_/g, " ")}
          </Link>
        ))}
      </div>
    </div>
  );
}
