import type { MetadataRoute } from "next";

// Static top-level routes only. For millions of book pages, generate a
// sitemap INDEX with paginated sub-sitemaps sourced from your database of
// crawled/cached work ids rather than listing books here directly — see
// README "Scaling search & SEO" section.
export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://example.com";
  return [
    { url: `${base}/`, changeFrequency: "daily", priority: 1 },
    { url: `${base}/search`, changeFrequency: "daily", priority: 0.8 },
    { url: `${base}/browse/genre/fantasy`, changeFrequency: "weekly", priority: 0.6 },
    { url: `${base}/blog`, changeFrequency: "weekly", priority: 0.5 },
  ];
}
