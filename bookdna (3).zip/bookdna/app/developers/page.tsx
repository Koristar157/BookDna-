export const metadata = { title: "Developer API" };

export default function DevelopersPage() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-20">
      <h1 className="font-display text-3xl text-ink-900 dark:text-parchment mb-4">Developer API</h1>
      <p className="font-body leading-relaxed text-ink-700 dark:text-ink-200 mb-4">
        BookDNA&rsquo;s own search endpoints are already real and usable:
      </p>
      <ul className="space-y-2 font-mono text-sm text-ink-600 dark:text-ink-300">
        <li>GET /api/search?q=&#123;query&#125;&amp;genre=&amp;mood=&amp;trope=&amp;theme=</li>
        <li>GET /api/autocomplete?q=&#123;query&#125;</li>
        <li>POST /api/ai-search &#123; "query": "a cozy fantasy with dragons" &#125;</li>
      </ul>
      <p className="mt-4 font-body text-ink-600 dark:text-ink-300">
        A public, rate-limited, API-key-gated version of these is a natural next step once this
        is deployed.
      </p>
    </div>
  );
}
