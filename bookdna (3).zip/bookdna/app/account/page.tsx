import { isSupabaseConfigured } from "@/lib/supabase";

export const metadata = { title: "Account" };

export default function AccountPage() {
  const configured = isSupabaseConfigured();

  return (
    <div className="mx-auto max-w-md px-6 py-20 text-center">
      <h1 className="font-display text-3xl text-ink-900 dark:text-parchment mb-4">Your account</h1>
      {configured ? (
        <p className="font-body text-ink-600 dark:text-ink-300">
          Supabase is connected. Wire up the sign-in form here using{" "}
          <code className="font-mono text-sm">@supabase/auth-helpers-nextjs</code> — the schema for
          shelves, reviews, and reading stats is already in <code className="font-mono text-sm">supabase/schema.sql</code>.
        </p>
      ) : (
        <p className="font-body text-ink-600 dark:text-ink-300">
          Accounts aren&rsquo;t connected yet. Create a Supabase project, run{" "}
          <code className="font-mono text-sm">supabase/schema.sql</code>, and add your project URL/keys to{" "}
          <code className="font-mono text-sm">.env.local</code> to enable sign-in, shelves, reviews, and reading stats.
        </p>
      )}
    </div>
  );
}
