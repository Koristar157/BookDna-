import Link from "next/link";

export default function Section({
  title,
  eyebrow,
  viewAllHref,
  children,
}: {
  title: string;
  eyebrow?: string;
  viewAllHref?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <div className="mb-6 flex items-end justify-between">
        <div>
          {eyebrow && (
            <p className="font-mono text-xs uppercase tracking-widest text-berry mb-1">{eyebrow}</p>
          )}
          <h2 className="font-display text-2xl font-medium text-ink-900 dark:text-parchment">{title}</h2>
        </div>
        {viewAllHref && (
          <Link href={viewAllHref} className="font-body text-sm text-ink-600 hover:text-berry dark:text-ink-300">
            View all →
          </Link>
        )}
      </div>
      {children}
    </section>
  );
}
