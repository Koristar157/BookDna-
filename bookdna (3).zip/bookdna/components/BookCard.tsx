import Image from "next/image";
import Link from "next/link";
import type { BookSummary } from "@/lib/types";

export default function BookCard({ book }: { book: BookSummary }) {
  return (
    <Link
      href={`/book/${book.workId}`}
      className="group block focus-ring rounded"
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden rounded bg-ink-100 dark:bg-ink-700 shadow-sm group-hover:shadow-lg transition-shadow">
        {book.coverUrl ? (
          <Image
            src={book.coverUrl}
            alt={`Cover of ${book.title}`}
            fill
            sizes="(max-width: 768px) 40vw, 200px"
            className="object-cover"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center p-3 text-center">
            <span className="font-display text-sm text-ink-500 dark:text-ink-300">
              No cover available
            </span>
          </div>
        )}
      </div>
      <h3 className="mt-2 line-clamp-2 font-display text-sm font-medium text-ink-900 dark:text-parchment group-hover:text-berry transition-colors">
        {book.title}
      </h3>
      <p className="line-clamp-1 font-body text-xs text-ink-500 dark:text-ink-300">
        {book.authors.length ? book.authors.join(", ") : "Unknown author"}
      </p>
    </Link>
  );
}
