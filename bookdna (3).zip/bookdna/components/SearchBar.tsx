"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import type { BookSummary } from "@/lib/types";

export default function SearchBar({ large = false }: { large?: boolean }) {
  const router = useRouter();
  const [value, setValue] = useState("");
  const [suggestions, setSuggestions] = useState<BookSummary[]>([]);
  const [open, setOpen] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (value.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/autocomplete?q=${encodeURIComponent(value)}`);
        if (!res.ok) return;
        const data = await res.json();
        setSuggestions(data.books ?? []);
        setOpen(true);
      } catch {
        // Silent — autocomplete is a nicety, not critical path.
      }
    }, 250);
  }, [value]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!value.trim()) return;
    setOpen(false);
    router.push(`/search?q=${encodeURIComponent(value)}`);
  }

  return (
    <div className="relative mx-auto w-full max-w-xl">
      <form onSubmit={submit} className="flex gap-2">
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onFocus={() => suggestions.length && setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          placeholder="Search by title, author, ISBN, or describe a vibe…"
          className={`focus-ring w-full rounded border border-ink-200 bg-white px-4 dark:bg-ink-800 dark:border-ink-600 dark:text-parchment ${
            large ? "py-4 text-base" : "py-2 text-sm"
          }`}
        />
        <button
          type="submit"
          className={`shrink-0 rounded bg-ink-900 text-parchment font-body hover:bg-berry transition-colors focus-ring dark:bg-parchment dark:text-ink-900 ${
            large ? "px-6 py-4" : "px-4 py-2 text-sm"
          }`}
        >
          Search
        </button>
      </form>

      {open && suggestions.length > 0 && (
        <ul className="absolute z-50 mt-2 w-full rounded border border-ink-100 bg-white shadow-lg dark:bg-ink-800 dark:border-ink-700 text-left overflow-hidden">
          {suggestions.map((s) => (
            <li key={s.workId}>
              <a
                href={`/book/${s.workId}`}
                className="flex items-center gap-3 px-4 py-2 hover:bg-parchment dark:hover:bg-ink-700"
              >
                <span className="font-body text-sm text-ink-900 dark:text-parchment">{s.title}</span>
                {s.authors[0] && (
                  <span className="font-body text-xs text-ink-400">— {s.authors[0]}</span>
                )}
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
