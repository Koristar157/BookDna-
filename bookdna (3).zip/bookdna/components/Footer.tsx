import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-ink-100 dark:border-ink-700 mt-24">
      <div className="spine-divider" />
      <div className="mx-auto max-w-6xl px-6 py-12 grid gap-8 md:grid-cols-4 font-body text-sm text-ink-600 dark:text-ink-300">
        <div>
          <p className="font-display text-lg text-ink-900 dark:text-parchment mb-2">
            Book<span className="text-berry">DNA</span>
          </p>
          <p>Real books. Real data. No fabricated ratings, ever.</p>
        </div>
        <div>
          <p className="font-semibold text-ink-900 dark:text-parchment mb-2">Discover</p>
          <ul className="space-y-1">
            <li><Link href="/browse/genre" className="hover:text-berry">Genres</Link></li>
            <li><Link href="/browse/mood" className="hover:text-berry">Moods</Link></li>
            <li><Link href="/blog" className="hover:text-berry">Blog</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-semibold text-ink-900 dark:text-parchment mb-2">Data sources</p>
          <ul className="space-y-1">
            <li>Open Library</li>
            <li>Google Books</li>
          </ul>
        </div>
        <div>
          <p className="font-semibold text-ink-900 dark:text-parchment mb-2">Company</p>
          <ul className="space-y-1">
            <li><Link href="/about" className="hover:text-berry">About</Link></li>
            <li><Link href="/developers" className="hover:text-berry">Developer API</Link></li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
