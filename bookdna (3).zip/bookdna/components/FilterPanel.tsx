"use client";

import { useRouter, useSearchParams } from "next/navigation";

const GENRES = ["fantasy", "romance", "mystery", "science fiction", "horror", "thriller"];
const TROPES = ["enemies to lovers", "found family", "slow burn", "morally gray", "heist", "dark academia"];
const MOODS = ["cozy", "dark", "fast-paced", "emotional"];

export default function FilterPanel({
  currentFilters,
}: {
  currentFilters: Record<string, string | number | undefined>;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();

  function setFilter(key: string, value: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (params.get(key) === value) {
      params.delete(key); // toggle off
    } else {
      params.set(key, value);
    }
    router.push(`/search?${params.toString()}`);
  }

  const Group = ({ label, values, filterKey }: { label: string; values: string[]; filterKey: string }) => (
    <div className="mb-6">
      <p className="mb-2 font-mono text-xs uppercase tracking-wider text-ink-400">{label}</p>
      <div className="flex flex-wrap gap-2 md:flex-col md:gap-1">
        {values.map((v) => {
          const active = currentFilters[filterKey] === v;
          return (
            <button
              key={v}
              onClick={() => setFilter(filterKey, v)}
              className={`rounded-full md:rounded px-3 py-1 text-left text-xs font-body capitalize transition-colors focus-ring ${
                active
                  ? "bg-berry text-white"
                  : "bg-ink-50 text-ink-600 hover:bg-ink-100 dark:bg-ink-800 dark:text-ink-300"
              }`}
            >
              {v}
            </button>
          );
        })}
      </div>
    </div>
  );

  return (
    <aside className="md:sticky md:top-24 md:self-start">
      <Group label="Genre" values={GENRES} filterKey="genre" />
      <Group label="Trope" values={TROPES} filterKey="trope" />
      <Group label="Mood" values={MOODS} filterKey="mood" />
    </aside>
  );
}
