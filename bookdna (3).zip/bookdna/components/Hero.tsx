import SearchBar from "./SearchBar";

export default function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-ink-100 dark:border-ink-700">
      <div className="absolute inset-0 bg-spine-lines opacity-40" aria-hidden />
      <div className="relative mx-auto max-w-4xl px-6 py-20 text-center">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-berry mb-4">
          Real books. Real data. Matched to you.
        </p>
        <h1 className="font-display text-4xl font-semibold leading-tight text-ink-900 dark:text-parchment sm:text-6xl">
          Find the book your{" "}
          <span className="italic text-berry">taste</span> already knows.
        </h1>
        <p className="mx-auto mt-5 max-w-xl font-body text-ink-600 dark:text-ink-300">
          Describe what you&rsquo;re in the mood for, in your own words. BookDNA
          reads it, and searches real, published books to match.
        </p>
        <div className="mt-8">
          <SearchBar large />
        </div>
        <p className="mt-3 font-body text-xs text-ink-400 dark:text-ink-500">
          Try: &ldquo;a cozy fantasy with dragons and almost no romance&rdquo;
        </p>
      </div>
    </section>
  );
}
