import type { BookDNATraits } from "@/lib/types";
import { TRAIT_LABELS } from "@/lib/bookdna-traits";

export default function TraitBars({ traits }: { traits: BookDNATraits }) {
  const entries = Object.entries(traits) as [keyof BookDNATraits, number][];

  return (
    <div>
      <div className="mb-3 flex items-center gap-2">
        <h3 className="font-display text-lg text-ink-900 dark:text-parchment">BookDNA Analysis</h3>
        <span className="rounded-full bg-ink-100 dark:bg-ink-700 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide text-ink-500 dark:text-ink-300">
          derived, not an official rating
        </span>
      </div>
      <div className="space-y-3">
        {entries.map(([key, value]) => (
          <div key={key}>
            <div className="mb-1 flex justify-between font-body text-xs text-ink-600 dark:text-ink-300">
              <span>{TRAIT_LABELS[key]}</span>
              <span className="font-mono">{value}</span>
            </div>
            <div className="trait-bar-track">
              <div className="trait-bar-fill" style={{ width: `${value}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
