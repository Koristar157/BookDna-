import type { BookSummary } from "@/lib/types";
import BookCard from "./BookCard";

export function EmptyState({ message = "No information available." }: { message?: string }) {
  return (
    <div className="rounded border border-dashed border-ink-200 dark:border-ink-700 py-12 text-center">
      <p className="font-body text-sm text-ink-500 dark:text-ink-300">{message}</p>
    </div>
  );
}

export default function BookGrid({ books }: { books: BookSummary[] }) {
  if (!books.length) return <EmptyState />;
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
      {books.map((book) => (
        <BookCard key={book.workId} book={book} />
      ))}
    </div>
  );
}
