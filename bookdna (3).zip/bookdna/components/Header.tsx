import Link from "next/link";

const NAV = [
  { href: "/search", label: "Search" },
  { href: "/browse/genre", label: "Genres" },
  { href: "/browse/mood", label: "Moods" },
  { href: "/blog", label: "Blog" },
];

export default function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-ink-100 bg-parchment/90 backdrop-blur dark:bg-ink-900/90 dark:border-ink-700">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-baseline gap-1 focus-ring rounded-sm">
          <span className="font-display text-2xl font-semibold tracking-tight text-ink-900 dark:text-parchment">
            Book<span className="text-berry">DNA</span>
          </span>
        </Link>

        <nav className="hidden gap-8 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="font-body text-sm text-ink-600 hover:text-berry transition-colors focus-ring rounded-sm dark:text-ink-200"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link
            href="/account"
            className="rounded border border-ink-900 px-4 py-1.5 text-sm font-body text-ink-900 hover:bg-ink-900 hover:text-parchment transition-colors focus-ring dark:border-parchment dark:text-parchment dark:hover:bg-parchment dark:hover:text-ink-900"
          >
            Sign in
          </Link>
        </div>
      </div>
    </header>
  );
}
