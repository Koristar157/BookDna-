// Server component: reads affiliate IDs from env at request time so no ID is
// ever committed to source. If an ID isn't configured, that retailer's link
// still points to a real, working search URL — just without an affiliate tag.

function amazonUrl(query: string) {
  const tag = process.env.AFFILIATE_AMAZON_TAG;
  const base = `https://www.amazon.com/s?k=${encodeURIComponent(query)}`;
  return tag ? `${base}&tag=${tag}` : base;
}
function bnUrl(query: string) {
  return `https://www.barnesandnoble.com/s/${encodeURIComponent(query)}`;
}
function bookshopUrl(query: string) {
  const id = process.env.AFFILIATE_BOOKSHOP_ID;
  const base = `https://bookshop.org/search?keywords=${encodeURIComponent(query)}`;
  return id ? `${base}&affiliate=${id}` : base;
}
function koboUrl(query: string) {
  return `https://www.kobo.com/search?query=${encodeURIComponent(query)}`;
}

export default function BuyLinks({ title, isbn }: { title: string; isbn: string | null }) {
  const query = isbn ?? title;
  const retailers = [
    { name: "Amazon", href: amazonUrl(query) },
    { name: "Barnes & Noble", href: bnUrl(query) },
    { name: "Bookshop.org", href: bookshopUrl(query) },
    { name: "Kobo", href: koboUrl(query) },
  ];

  return (
    <div className="space-y-2">
      <p className="font-mono text-[10px] uppercase tracking-wider text-ink-400">Buy this book</p>
      {retailers.map((r) => (
        <a
          key={r.name}
          href={r.href}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="block rounded border border-ink-200 dark:border-ink-600 px-3 py-2 text-center font-body text-sm text-ink-900 dark:text-parchment hover:border-berry hover:text-berry transition-colors focus-ring"
        >
          {r.name}
        </a>
      ))}
    </div>
  );
}
